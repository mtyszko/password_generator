const btn = document.querySelector('button');
const cnt = document.querySelector('.container')
let charsNumber = 10;
let codesNumber = 10;
const chars = `ABCDEFGHIJKLMNOQPRSTUVWXYZ1234567890!@#$%^&*()_+-=?`;
const charsArray = chars.split('');
const charsInput = document.querySelector('.chars');
const codesInput = document.querySelector('.codes');
// wczytanie ilości znaków
charsInput.addEventListener('change', (e) => {
  charsNumber = e.target.value * 1;
  (typeof charsNumber === 'number') && (charsNumber >= 3 && charsNumber <= 30) ?
  charsNumber: charsError();
});

// error message (zastanowić się jak do obu przypadków użyć jednej funkcji)
charsError = () => {
  alert(`Podaj liczbę z zakresu 3 do 30`);
  charsNumber = '';
  charsInput.value = ``;
};


// wczytanie ilości kodów
codesInput.addEventListener('change', (e) => {
  codesNumber = e.target.value * 1;
  (typeof codesNumber === 'number') && (codesNumber >= 1 && codesNumber <= 100) ?
  codesNumber: codesError();
});
// error message (zastanowić się jak do obu przypadków użyć jednej funkcji)

codesError = () => {
  alert(`Podaj liczbę z zakresu 1 do 100`);
  codesNumber = '';
  codesInput.value = ``;
};
// losowanie kodów
const randomCodes = function() {
  cnt.style.display = `block`;
  cnt.innerHTML = ``;
  for (let i = 0; i < codesNumber; i++) {
    let code = '';
    for (let j = 0; j < charsNumber; j++) {
      code += charsArray[Math.floor(Math.random() * charsArray.length)];

    };
    const p = document.createElement('p');
    p.textContent = code;
    cnt.appendChild(p);
  };
}




// stylowanie formularza po akcjach

// zaznaczanie
charsInput.addEventListener('focus', (e) => {
  e.target.classList.add('active');
});
//odznaczenie
charsInput.addEventListener('blur', (e) => {
  e.target.classList.remove('active')
});

//zaznaczanie
codesInput.addEventListener('focus', (e) => {
  e.target.classList.add('active');
});
//odznaczenie
codesInput.addEventListener('blur', (e) => {
  e.target.classList.remove('active')
});



btn.addEventListener('click', randomCodes);
"use strict";
const MainButton = {
  state: true,
  langPl: "wygeneruj hasło",
  langEng: "generate password",
  langPlPlural: "wygeneruj hasła",
  langEngPlural: "generate passwords",
  buttonContainer: document.querySelector(".btn__container"),
  button: document.querySelector(".main__btn"),
  codes: document.querySelector(".codes"),
  goBack: document.querySelector(".go__back"),
  codesArray: []
};

const charContainer = document.querySelector(".temp__animation");
const goBackBtn = document.querySelector(".go__back");
const p = document.querySelector(".code__item");
const validator = () => {
  if (
    (SmallLetters.state ||
      BigLetters.state ||
      Numbers.state ||
      SpecialChars.state) &&
    changeNumber
  ) {
    MainButton.button.classList.add("active");
    return true;
  } else {
    MainButton.button.classList.remove("active");
    return false;
  }
};
const getPassword = () => {
  validator();
  if (MainButton.button.classList.contains("active")) {
    p.textContent = "";
    let charNumber = CharsNumber.charsNumber;
    let code = "";
    for (let j = 0; j < CharsNumber.charsNumber; j++) {
      code += charsSelected[Math.floor(Math.random() * charsSelected.length)];
    }
    p.textContent = code;
  }
};

const showButtons = () => {
  MainButton.codes.style.color = "#222";
  MainButton.codes.style.zIndex = "2";
  MainButton.buttonContainer.style.color = "#222";
  MainButton.buttonContainer.style.zIndex = "2";
  MainButton.buttonContainer.classList.add("animated");
};

const hideButtons = () => {
  MainButton.codes.style.color = "#ffffff";
  MainButton.codes.style.zIndex = "-2";
  MainButton.buttonContainer.style.color = "#ffffff";
  MainButton.buttonContainer.style.zIndex = "-2";
  MainButton.buttonContainer.classList.remove("animated");
};

const hideGenerateButton = () => {
  MainButton.button.style.color = "#ffffff";
  MainButton.button.style.zIndex = "-2";
  MainButton.button.classList.remove("animated");
};

const showGenerateButton = () => {
  MainButton.button.style.color = "#222";
  MainButton.button.style.zIndex = "2";
  MainButton.button.classList.add("animated");
  p.textContent = "";
};

// optional animation
// const animateChars = () => {
//   let char =''
//   char = charsSelected[Math.floor(Math.random() * charsSelected.length)]
//   charContainer.textContent = char

// }

const generatePass = () => {
  getPassword();
  hideGenerateButton();
  setTimeout(showButtons, 400);
};

const goBack = () => {
  hideButtons();
  setTimeout(showGenerateButton, 400);
};

MainButton.button.addEventListener("click", generatePass);
goBackBtn.addEventListener("click", goBack);

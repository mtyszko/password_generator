'use strict'
class Checkbox {
  constructor(name,labelPl,labelEng,state,labelName,inputName){
    this.name = name;
    this.labelPl = labelPl;
    this.labelEng = labelEng;
    this.state = state;
    this.labelName = `.${labelName}`;
    this.inputName = `.${inputName}`;
  }

  changeTitle (){
    if(langState.state === 'pl'){
      document.querySelector(this.labelName).textContent = this.labelPl;
    }
    else if(langState.state === 'eng'){
      document.querySelector(this.labelName).textContent = this.labelEng;
    }
  }
}
const SmallLetters = new Checkbox('smallLetters','małe litery','small letters',true,'label__smallLetters','input__smallLetters');
SmallLetters.chars = Chars.smallLetters
const BigLetters = new Checkbox('bigLetters','wielkie litery','big letters',true,'label__bigLetters','input__bigLetters');
BigLetters.chars = Chars.bigLetters
const Numbers = new Checkbox('numbers','cyfry','numbers',true,'label__numbers','input__numbers');
Numbers.chars = Chars.numbers
const SpecialChars = new Checkbox('specialChars','małe litery','special characters',true,'label__specialChars','input__specialChars');
SpecialChars.chars = Chars.specialChars

const checkboxArray = [SmallLetters,BigLetters,Numbers,SpecialChars];
// checkboxArray.forEach(item => {
//   const name = `${item.name}`
//   item.chars = Chars.name;
// })
checkboxArray.forEach(item => item.input = document.querySelector(item.inputName))
checkboxArray.forEach(item => item.label = document.querySelector(item.labelName))

checkboxArray.forEach(item => {
  const input = item.input
  const stateChanger = () => {
    item.state = !item.state
    makebaseForRandom()
    validator()
  }
  input.addEventListener('click', stateChanger)
  return charsSelected
});

const makebaseForRandom = () => {
  charsSelected = ''
  checkboxArray.forEach(item => {
  if(item.state) {
    charsSelected = charsSelected.concat(item.chars)
  }
})
return charsSelected
}








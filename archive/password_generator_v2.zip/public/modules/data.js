'use strict'
const Chars = {
  smallLetters: "abcdefghijklmnopqrtsuvwxyz",
  bigLetters: "ABCDEFGHIJKLMNOPQRSTUVWXYZ",
  specialChars:"!@#$%^&*(),./?';:{}[]=+-_§£~",
  numbers :"1234567890"
}
let charsSelected = `${Chars.smallLetters}${Chars.bigLetters}${Chars.numbers}${Chars.specialChars}`


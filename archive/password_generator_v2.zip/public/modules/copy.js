'use strict'
const copy = document.querySelector('.copy__btn');
const codes = document.querySelector('.codes')
const copyToClipboard = () => {
  const tempArea = document.createElement('textarea');
  codes.appendChild(tempArea)
  tempArea.textContent = p.textContent
  tempArea.select()
  document.execCommand('copy')
  codes.removeChild(tempArea)
}
copy.addEventListener('click',copyToClipboard)
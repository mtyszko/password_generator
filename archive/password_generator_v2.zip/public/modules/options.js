'use strict'
const Options = {
  state: false,
  optionsPl: 'opcje',
  optionsEng:'options',
  arrow: document.querySelector('.arrow'),
  options: document.querySelector('.options'),
  optionsContainer: document.querySelector('.options__container'),
  mask: document.querySelector('.mask')
}

const handleOptions = () => {

  Options.state = !Options.state
  if(!Options.state){
    Options.mask.style.top = '30px'
    Options.arrow.style.transform = 'rotate(0)'
}else{
  Options.mask.style.top = '230px'
  Options.arrow.style.transform = 'rotate(90deg)'
}
}
Options.options.addEventListener('click',handleOptions);
"use strict";
const CharsNumber = {
  charsNumber: 12,
  labelPl: "ile znaków?",
  infoPl: "minimum 3 maksymalnie 32",
  errorMaxPl: "maksymalna ilość znaków to 32",
  errorMinPl: "minimalna ilośc znaków to 3",
  errorLettersPl: "czego nie zrozumiałeś/-aś? podaj LICZBĘ od 3 do 32",
  labelEng: "number of characters?",
  infoEng: "require number from 3 to 32",
  errorMaxEng: "max number is 32",
  errorMinEng: "min number is 3",
  errorLettersEng: "are you stupid? it has to be a NUMBRER from 3 to 32!",
  state: true,
  label: document.querySelector(".label__charsNumber"),
  input: document.querySelector(".input__charsNumber"),
  info: document.querySelector(".chars__info")
};
const changeNumber = () => {
  const _tempNumber = isNaN(Number(CharsNumber.input.value));
  const _charsNumber = parseInt(CharsNumber.input.value);
  if (_charsNumber >= 3 && _charsNumber <= 32 && !_tempNumber) {
    if (langState.state === "pl") {
      CharsNumber.info.textContent = CharsNumber.infoPl;
      CharsNumber.info.style.color = "#222";
    } else if (langState.state === "eng") {
      CharsNumber.info.textContent = CharsNumber.infoEng;
      CharsNumber.info.style.color = "#222";
    }
    CharsNumber.charsNumber = parseInt(CharsNumber.input.value);
    return true;
  } else if (_charsNumber < 3 && !_tempNumber) {
    if (langState.state === "pl") {
      CharsNumber.info.textContent = CharsNumber.errorMinPl;
      CharsNumber.info.style.color = "#FF2B20";
    } else if (langState.state === "eng") {
      CharsNumber.info.textContent = CharsNumber.errorMinEng;
      CharsNumber.info.style.color = "#FF2B20";
    }
    return false;
  } else if (_charsNumber > 32 && !_tempNumber) {
    if (langState.state === "pl") {
      CharsNumber.info.textContent = CharsNumber.errorMaxPl;
      CharsNumber.info.style.color = "#FF2B20";
    } else if (langState.state === "eng") {
      CharsNumber.info.textContent = CharsNumber.errorMaxEng;
      CharsNumber.info.style.color = "#FF2B20";
    }
    return false;
  } else if (typeof CharsNumber.input.value === "string") {
    if (langState.state === "pl") {
      CharsNumber.info.textContent = CharsNumber.errorLettersPl;
      CharsNumber.info.style.color = "#FF2B20";
    } else if (langState.state === "eng") {
      CharsNumber.info.textContent = CharsNumber.errorLettersEng;
      CharsNumber.info.style.color = "#FF2B20";
    }
    return false;
  } else if (
    isNaN(Number(CharsNumber.input.value)) ||
    CharsNumber.input.value === ""
  ) {
    CharsNumber.charsNumber = 12;
    return true;
  }
};
CharsNumber.input.addEventListener("input", changeNumber);
CharsNumber.input.addEventListener("input", validator);

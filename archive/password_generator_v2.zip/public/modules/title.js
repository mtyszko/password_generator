'use strict'
const Title = {
  lang: 'pl',
  langPl: '{Generator Haseł}',
  langEng: '{Password Generator}',
  header: document.querySelector('.title__text')
}
"use strict";
const langState = {
  state: "pl"
};

const changeLang = lang => {

  langState.state = lang;
  if (langState.state === "pl") {
    CharsNumber.label.textContent = CharsNumber.labelPl;
    CharsNumber.info.textContent = CharsNumber.infoPl;
    Options.options.textContent = Options.optionsPl;
    MainButton.button.textContent = MainButton.langPl;
    Title.header.textContent = Title.langPl;
    copy.textContent = "kopiuj do schowka";
    goBackBtn.textContent = 'powrót'
  } else if (langState.state === "eng") {
    CharsNumber.label.textContent = CharsNumber.labelEng;
    CharsNumber.info.textContent = CharsNumber.infoEng;
    Options.options.textContent = Options.optionsEng;
    MainButton.button.textContent = MainButton.langEng;
    Title.header.textContent = Title.langEng;
    copy.textContent = "copy to clipboard";
    goBackBtn.textContent = 'back'
  }
  checkboxArray.forEach(item => {
    item.changeTitle();
  });
  changeNumber();
};

const pl = document.querySelector(".pl");
const eng = document.querySelector(".eng");

const handlePl = () => changeLang("pl");
const handleEng = () => changeLang("eng");
const clearAnimation = () => {
  const animatedArray = [...document.querySelectorAll(".animated")];
  animatedArray.forEach(item => (item.style.animation = "none"));
};
const changeToPl = () => {
  const animatedArray = [...document.querySelectorAll(".animated")];
  if (langState.state === "eng") {
    animatedArray.forEach(
      item => (item.style.animation = "mainAnimation 2s both")
    );
    setTimeout("handlePl()", 1000);
    setTimeout("clearAnimation()", 2000);
  }
};
const changeToEng = () => {
  const animatedArray = [...document.querySelectorAll(".animated")];
  if (langState.state === "pl") {
    animatedArray.forEach(
      item => (item.style.animation = "mainAnimation 2s both")
    );
    setTimeout("handleEng()", 1000);
    setTimeout("clearAnimation()", 2000);
  }
};
pl.addEventListener("click", changeToPl);
eng.addEventListener("click", changeToEng);

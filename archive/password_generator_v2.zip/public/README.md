# Password generator
## Features
This little javascript app generates random password from letters, numbers and special characters held in array
##Vervions
### v1
uder decides how many passwords is needed (max 100!), and how many signs pre passwords (range: 3-30);

Options to implement:
chosing characters (numbers, letters, special characters)
cursor pointer on button
range in input field
user cannot add value that is not float (bez przecinków)
mix of number and string should not be allowed

"use strict";
document.querySelector(".wrapper").style.display = "block";
document.querySelector(".info__wrapper").style.display = "none";

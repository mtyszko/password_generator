# Password generator v 3.0.0

This project is made to learn React and Sass
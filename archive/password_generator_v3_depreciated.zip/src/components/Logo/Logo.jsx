import React from 'react';

const Logo = () => {
  return <div className='logo'>tu będzie logo</div>;
};

export default Logo;

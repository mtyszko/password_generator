import React, { Component } from 'react';
import GenerateBtn from './Button/GenerateBtn';
import OptionsContainer from './Options/OptionsContainer';
import CopyToClipBtn from './Button/CopyToClipBtn';
import PassArea from './PassArea/PassArea';
import styles from './MainContainer.module.scss';
import PropTypes from 'prop-types';

const MainContainer = props => {
  const {
    mainBtn,
    password,
    errorMessage,
    getCheckboxData,
    getCharsNumber,
    getPassword,
    copyPassword,
    copyToClipboardLang
  } = props;
  return (
    <div className={styles.wrapper}>
      <GenerateBtn
        mainBtn={mainBtn}
        errorMessage={errorMessage}
        generatePassword={getPassword}
        {...props}
      />
      <OptionsContainer
        getCheckboxData={getCheckboxData}
        getCharsNumber={getCharsNumber}
        {...props}
      />
      <PassArea password={password} />
      <CopyToClipBtn
        copyPassword={copyPassword}
        copyToClipboardLang={copyToClipboardLang}
      />
    </div>
  );
};
MainContainer.propTypes = {};

export default MainContainer;

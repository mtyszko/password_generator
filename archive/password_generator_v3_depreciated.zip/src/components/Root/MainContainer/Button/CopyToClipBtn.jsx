import React from 'react';
import PropTypes from 'prop-types';

const CopyToClipBtn = props => {
  const { copyToClipboardLang, copyPassword } = props;
  return (
    <button className='btn btn__blue btn__copy' onClick={copyPassword}>
      {copyToClipboardLang}
    </button>
  );
};

CopyToClipBtn.propTypes = {};

export default CopyToClipBtn;

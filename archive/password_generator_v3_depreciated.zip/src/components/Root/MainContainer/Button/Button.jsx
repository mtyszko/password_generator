import React from 'react'

const Button = () => ()

export default Button
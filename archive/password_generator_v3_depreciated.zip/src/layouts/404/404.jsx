import React from 'react';

const FourOFour = () => {
  return <div className='four__o__four'>Houston mamy problem</div>;
};

export default FourOFour;
